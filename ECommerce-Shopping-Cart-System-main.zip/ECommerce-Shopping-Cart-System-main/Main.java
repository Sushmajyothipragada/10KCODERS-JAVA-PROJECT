import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * E-Commerce Shopping Cart System
 * Educational Core Java console project.
 * Default admin login: admin / admin123
 */
public class Main {
    private static final Scanner SC = new Scanner(System.in);
    private static final String DATA_FILE = "shopping_cart_data.ser";
    private static AppData data = loadData();

    public static void main(String[] args) {
        seedProductsIfNeeded();
        saveData();

        System.out.println("======================================");
        System.out.println("   E-COMMERCE SHOPPING CART SYSTEM");
        System.out.println("======================================");

        while (true) {
            System.out.println("\nMAIN MENU");
            System.out.println("1. User Registration");
            System.out.println("2. User Login");
            System.out.println("3. Admin Login");
            System.out.println("4. View Products");
            System.out.println("5. Exit");

            int choice = readInt("Choose an option: ");
            switch (choice) {
                case 1 -> registerUser();
                case 2 -> userLogin();
                case 3 -> adminLogin();
                case 4 -> showProducts();
                case 5 -> {
                    saveData();
                    System.out.println("Thank you for using the application!");
                    return;
                }
                default -> System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void registerUser() {
        System.out.println("\n--- USER REGISTRATION ---");
        String username = readNonEmpty("Create username: ");
        if (data.users.containsKey(username.toLowerCase(Locale.ROOT))) {
            System.out.println("That username already exists.");
            return;
        }
        String password = readNonEmpty("Create password: ");
        String name = readNonEmpty("Full name: ");
        String phone = readNonEmpty("Contact number: ");

        User user = new User(username, password, name, phone);
        data.users.put(username.toLowerCase(Locale.ROOT), user);
        saveData();
        System.out.println("Registration successful. You can now log in.");
    }

    private static void userLogin() {
        System.out.println("\n--- USER LOGIN ---");
        String username = readNonEmpty("Username: ");
        String password = readNonEmpty("Password: ");
        User user = data.users.get(username.toLowerCase(Locale.ROOT));

        if (user == null || !user.password.equals(password)) {
            System.out.println("Invalid username or password.");
            return;
        }

        System.out.println("Welcome, " + user.name + "!");
        userMenu(user);
    }

    private static void userMenu(User user) {
        Map<Integer, Integer> cart = new LinkedHashMap<>();
        while (true) {
            System.out.println("\nUSER MENU");
            System.out.println("1. View Products");
            System.out.println("2. Add Product to Cart");
            System.out.println("3. View Cart");
            System.out.println("4. Remove Product from Cart");
            System.out.println("5. Checkout");
            System.out.println("6. My Order History");
            System.out.println("7. Logout");

            int choice = readInt("Choose an option: ");
            switch (choice) {
                case 1 -> showProducts();
                case 2 -> addToCart(cart);
                case 3 -> viewCart(cart);
                case 4 -> removeFromCart(cart);
                case 5 -> checkout(user, cart);
                case 6 -> showOrderHistory(user.username);
                case 7 -> { return; }
                default -> System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void addToCart(Map<Integer, Integer> cart) {
        showProducts();
        int id = readInt("Enter product ID to add: ");
        Product product = findProduct(id);
        if (product == null) {
            System.out.println("Product not found.");
            return;
        }
        int quantity = readInt("Quantity: ");
        if (quantity <= 0) {
            System.out.println("Quantity must be greater than zero.");
            return;
        }
        cart.put(id, cart.getOrDefault(id, 0) + quantity);
        System.out.println(quantity + " x " + product.name + " added to cart.");
    }

    private static void viewCart(Map<Integer, Integer> cart) {
        System.out.println("\n--- YOUR CART ---");
        if (cart.isEmpty()) {
            System.out.println("Your cart is empty.");
            return;
        }
        double total = 0;
        for (Map.Entry<Integer, Integer> entry : cart.entrySet()) {
            Product p = findProduct(entry.getKey());
            if (p != null) {
                double subtotal = p.price * entry.getValue();
                total += subtotal;
                System.out.printf("%-22s x %-3d Rs. %.2f%n", p.name, entry.getValue(), subtotal);
            }
        }
        System.out.printf("Cart total: Rs. %.2f%n", total);
    }

    private static void removeFromCart(Map<Integer, Integer> cart) {
        if (cart.isEmpty()) {
            System.out.println("Your cart is empty.");
            return;
        }
        viewCart(cart);
        int id = readInt("Enter product ID to remove: ");
        if (cart.remove(id) != null) {
            System.out.println("Product removed from cart.");
        } else {
            System.out.println("That product is not in your cart.");
        }
    }

    private static void checkout(User user, Map<Integer, Integer> cart) {
        if (cart.isEmpty()) {
            System.out.println("Your cart is empty. Add products before checkout.");
            return;
        }
        viewCart(cart);
        String confirm = readNonEmpty("Confirm order? (yes/no): ");
        if (!confirm.equalsIgnoreCase("yes")) {
            System.out.println("Checkout cancelled.");
            return;
        }

        List<OrderItem> items = new ArrayList<>();
        double total = 0;
        for (Map.Entry<Integer, Integer> entry : cart.entrySet()) {
            Product p = findProduct(entry.getKey());
            if (p != null) {
                items.add(new OrderItem(p.id, p.name, p.price, entry.getValue()));
                total += p.price * entry.getValue();
            }
        }
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        Order order = new Order(data.nextOrderId++, user.username, items, total, timestamp);
        data.orders.add(order);
        cart.clear();
        saveData();
        System.out.printf("Order placed successfully! Order ID: %d | Total: Rs. %.2f%n", order.id, order.total);
    }

    private static void showOrderHistory(String username) {
        System.out.println("\n--- MY ORDER HISTORY ---");
        boolean found = false;
        for (Order order : data.orders) {
            if (order.username.equalsIgnoreCase(username)) {
                found = true;
                printOrder(order);
            }
        }
        if (!found) System.out.println("No orders found.");
    }

    private static void adminLogin() {
        System.out.println("\n--- ADMIN LOGIN ---");
        String username = readNonEmpty("Admin username: ");
        String password = readNonEmpty("Admin password: ");
        if (!username.equals("admin") || !password.equals("admin123")) {
            System.out.println("Invalid admin credentials.");
            return;
        }
        adminMenu();
    }

    private static void adminMenu() {
        while (true) {
            System.out.println("\nADMIN MENU");
            System.out.println("1. View Products");
            System.out.println("2. Add Product");
            System.out.println("3. Update Product Price");
            System.out.println("4. Delete Product");
            System.out.println("5. View All Orders / Report");
            System.out.println("6. Logout");

            int choice = readInt("Choose an option: ");
            switch (choice) {
                case 1 -> showProducts();
                case 2 -> addProduct();
                case 3 -> updateProductPrice();
                case 4 -> deleteProduct();
                case 5 -> showAllOrders();
                case 6 -> { return; }
                default -> System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void addProduct() {
        String name = readNonEmpty("Product name: ");
        String category = readNonEmpty("Category: ");
        double price = readDouble("Price (Rs.): ");
        if (price <= 0) {
            System.out.println("Price must be greater than zero.");
            return;
        }
        int id = data.nextProductId++;
        data.products.add(new Product(id, name, category, price));
        saveData();
        System.out.println("Product added successfully. Product ID: " + id);
    }

    private static void updateProductPrice() {
        showProducts();
        int id = readInt("Enter product ID: ");
        Product p = findProduct(id);
        if (p == null) {
            System.out.println("Product not found.");
            return;
        }
        double price = readDouble("Enter new price (Rs.): ");
        if (price <= 0) {
            System.out.println("Price must be greater than zero.");
            return;
        }
        p.price = price;
        saveData();
        System.out.println("Product price updated successfully.");
    }

    private static void deleteProduct() {
        showProducts();
        int id = readInt("Enter product ID to delete: ");
        Product p = findProduct(id);
        if (p == null) {
            System.out.println("Product not found.");
            return;
        }
        data.products.remove(p);
        saveData();
        System.out.println("Product deleted successfully.");
    }

    private static void showAllOrders() {
        System.out.println("\n--- ALL ORDERS REPORT ---");
        if (data.orders.isEmpty()) {
            System.out.println("No orders have been placed yet.");
            return;
        }
        double revenue = 0;
        for (Order order : data.orders) {
            printOrder(order);
            revenue += order.total;
        }
        System.out.printf("Total orders: %d | Total revenue: Rs. %.2f%n", data.orders.size(), revenue);
    }

    private static void printOrder(Order order) {
        System.out.printf("%nOrder #%d | User: %s | Date: %s | Total: Rs. %.2f%n",
                order.id, order.username, order.timestamp, order.total);
        for (OrderItem item : order.items) {
            System.out.printf("  - %s x %d (Rs. %.2f each)%n", item.name, item.quantity, item.price);
        }
    }

    private static void showProducts() {
        System.out.println("\n--- PRODUCT CATALOG ---");
        if (data.products.isEmpty()) {
            System.out.println("No products available.");
            return;
        }
        System.out.printf("%-6s %-24s %-16s %s%n", "ID", "Product", "Category", "Price");
        System.out.println("--------------------------------------------------------------");
        for (Product p : data.products) {
            System.out.printf("%-6d %-24s %-16s Rs. %.2f%n",
                    p.id, p.name, p.category, p.price);
        }
    }

    private static Product findProduct(int id) {
        for (Product p : data.products) {
            if (p.id == id) return p;
        }
        return null;
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(SC.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid whole number.");
            }
        }
    }

    private static double readDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Double.parseDouble(SC.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number, such as 499 or 499.50.");
            }
        }
    }

    private static String readNonEmpty(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = SC.nextLine().trim();
            if (!value.isEmpty()) return value;
            System.out.println("This field cannot be empty.");
        }
    }

    private static AppData loadData() {
        File file = new File(DATA_FILE);
        if (!file.exists()) return new AppData();
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
            Object loaded = in.readObject();
            if (loaded instanceof AppData) return (AppData) loaded;
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Could not load saved data. Starting with fresh data.");
        }
        return new AppData();
    }

    private static void saveData() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(DATA_FILE))) {
            out.writeObject(data);
        } catch (IOException e) {
            System.out.println("Warning: data could not be saved: " + e.getMessage());
        }
    }

    private static void seedProductsIfNeeded() {
        if (!data.products.isEmpty()) return;
        data.products.add(new Product(data.nextProductId++, "Wireless Mouse", "Electronics", 599.00));
        data.products.add(new Product(data.nextProductId++, "USB Keyboard", "Electronics", 799.00));
        data.products.add(new Product(data.nextProductId++, "Water Bottle", "Accessories", 249.00));
        data.products.add(new Product(data.nextProductId++, "Notebook Set", "Stationery", 199.00));
        data.products.add(new Product(data.nextProductId++, "Backpack", "Accessories", 999.00));
    }
}

class AppData implements Serializable {
    private static final long serialVersionUID = 1L;
    Map<String, User> users = new HashMap<>();
    List<Product> products = new ArrayList<>();
    List<Order> orders = new ArrayList<>();
    int nextProductId = 1;
    int nextOrderId = 1001;
}

class User implements Serializable {
    private static final long serialVersionUID = 1L;
    String username;
    String password;
    String name;
    String phone;

    User(String username, String password, String name, String phone) {
        this.username = username;
        this.password = password;
        this.name = name;
        this.phone = phone;
    }
}

class Product implements Serializable {
    private static final long serialVersionUID = 1L;
    int id;
    String name;
    String category;
    double price;

    Product(int id, String name, String category, double price) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.price = price;
    }
}

class Order implements Serializable {
    private static final long serialVersionUID = 1L;
    int id;
    String username;
    List<OrderItem> items;
    double total;
    String timestamp;

    Order(int id, String username, List<OrderItem> items, double total, String timestamp) {
        this.id = id;
        this.username = username;
        this.items = items;
        this.total = total;
        this.timestamp = timestamp;
    }
}

class OrderItem implements Serializable {
    private static final long serialVersionUID = 1L;
    int productId;
    String name;
    double price;
    int quantity;

    OrderItem(int productId, String name, double price, int quantity) {
        this.productId = productId;
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }
}
